package tp1.ejercicio1;

import java.util.ArrayList;
import java.util.List;

public class Agenda {

    private List<Reunion> reuniones;

    public Agenda() {
        this.reuniones = new ArrayList<>();
    }

    public List<Reunion> getReuniones() {
        return reuniones;
    }

    public void agregarReunion(Reunion reunion) {
        reuniones.add(reunion);
    }

    public void eliminarReunion(Reunion reunion) {
    reuniones.remove(reunion);
    }
}
