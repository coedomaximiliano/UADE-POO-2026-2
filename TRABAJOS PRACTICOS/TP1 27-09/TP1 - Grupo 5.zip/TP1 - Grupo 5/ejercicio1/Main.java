package tp1.ejercicio1;

public class Main {

    public static void main(String[] args) {

        Persona persona1 = new Persona("Facundo");
        Persona persona2 = new Persona("Juan");

        Reunion reunion1 = new Reunion(
                "Aula B004",
                "Trabajo Practico 1",
                60
        );

        reunion1.agregarParticipante(persona1);
        reunion1.agregarParticipante(persona2);

        Agenda agenda = new Agenda();

        agenda.agregarReunion(reunion1);

        System.out.println("Tema: " + reunion1.getTema());
        System.out.println("Lugar: " + reunion1.getLugar());
        System.out.println("Duracion: " + reunion1.getDuracionMinutos() + " minutos");

        System.out.println("Participantes:");

        for (Persona persona : reunion1.getParticipantes()) {
            System.out.println("- " + persona.getNombre());
        }

        System.out.println("Cantidad de reuniones en la agenda: "
                + agenda.getReuniones().size());
    }
}