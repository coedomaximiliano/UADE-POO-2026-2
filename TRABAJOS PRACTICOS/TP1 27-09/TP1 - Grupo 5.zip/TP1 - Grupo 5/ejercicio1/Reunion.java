package tp1.ejercicio1;

import java.util.ArrayList;
import java.util.List;

public class Reunion {

    private String lugar;
    private String tema;
    private int duracionMinutos;
    private List<Persona> participantes;

    public Reunion(String lugar, String tema, int duracionMinutos) {
        this.lugar = lugar;
        this.tema = tema;
        this.duracionMinutos = duracionMinutos;
        this.participantes = new ArrayList<>();
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    public int getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(int duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    public List<Persona> getParticipantes() {
        return participantes;
    }

    public void agregarParticipante(Persona persona) {
        participantes.add(persona);
    }

    public void quitarParticipante(Persona persona) {
        participantes.remove(persona);
    }
}
