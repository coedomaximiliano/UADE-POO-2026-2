package tp1.ejercicio2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        // Crear ciudades
        Ciudad madrid = new Ciudad("Madrid");
        Ciudad paris = new Ciudad("Paris");


        // Crear vuelos disponibles
        Vuelo vuelo1 = new Vuelo(
                101,
                LocalDate.of(2026, 10, 10),
                50,
                madrid
        );

        Vuelo vuelo2 = new Vuelo(
                102,
                LocalDate.of(2026, 10, 15),
                0,
                paris
        );


        // Lista de vuelos del sistema
        List<Vuelo> vuelos = new ArrayList<>();

        vuelos.add(vuelo1);
        vuelos.add(vuelo2);


        // Crear persona
        Persona persona = new Persona(
                "Facundo",
                12345678
        );


        // Crear sistema de reservas
        SistemaReservas sistema = new SistemaReservas();


        // Buscar vuelos disponibles
        List<Vuelo> disponibles = sistema.buscarVuelos(
                vuelos,
                madrid,
                LocalDate.of(2026, 10, 1),
                LocalDate.of(2026, 10, 20),
                "Turista",
                "No fumador"
        );


        System.out.println("Vuelos disponibles:");

        for (Vuelo vuelo : disponibles) {
            System.out.println("Vuelo encontrado");
        }


        // Si hay vuelos disponibles, hacemos la reserva
        if (!disponibles.isEmpty()) {

            Vuelo vueloElegido = disponibles.get(0);


            Reserva reserva = new Reserva(
                    LocalDate.of(2026, 10, 1),
                    LocalDate.of(2026, 10, 20),
                    "Turista",
                    "No fumador"
            );


            Reserva reservaConfirmada = sistema.registrarReserva(
                    persona,
                    vueloElegido,
                    reserva
            );


            System.out.println("Reserva realizada correctamente");
        }
        else {
            System.out.println("No hay vuelos disponibles");
        }
    }
}