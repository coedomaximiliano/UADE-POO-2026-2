package tp1.ejercicio2;

public class Pasaje {

    private int numero;

    public Pasaje(int numero) {
        this.numero = numero;
    }
}
