package tp1.ejercicio2;

import java.time.LocalDate;

public class Reserva {

    private LocalDate fechaInicio;
    private LocalDate fechaFin;
    private String clase;
    private String subseccion;

    private Persona persona;
    private Vuelo vuelo;
    private Pasaje pasaje;

    private static int proximoNumeroPasaje = 1;

    public Reserva(LocalDate fechaInicio, LocalDate fechaFin, String clase, String subseccion) {
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.clase = clase;
        this.subseccion = subseccion;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public void confirmar() {
        this.pasaje = new Pasaje(proximoNumeroPasaje);
        proximoNumeroPasaje++;
    }
}