package tp1.ejercicio2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SistemaReservas {

    public List<Vuelo> buscarVuelos(
            List<Vuelo> vuelos,
            Ciudad destino,
            LocalDate fechaInicio,
            LocalDate fechaFin,
            String clase,
            String subseccion) {

        List<Vuelo> vuelosDisponibles = new ArrayList<>();

        for (Vuelo vuelo : vuelos) {

            boolean mismoDestino =
                    vuelo.getDestino()
                            .getNombre()
                            .equalsIgnoreCase(destino.getNombre());

            boolean dentroDeFechas =
                    !vuelo.getFecha().isBefore(fechaInicio)
                            && !vuelo.getFecha().isAfter(fechaFin);

            if (mismoDestino
                    && dentroDeFechas
                    && vuelo.hayDisponibilidad()) {

                vuelosDisponibles.add(vuelo);
            }
        }

        return vuelosDisponibles;
    }

    public Reserva registrarReserva(
            Persona persona,
            Vuelo vuelo,
            Reserva reserva) {

        if (!vuelo.hayDisponibilidad()) {
            return null;
        }

        reserva.setPersona(persona);
        reserva.setVuelo(vuelo);

        vuelo.reservarLugar();

        reserva.confirmar();

        return reserva;
    }
}