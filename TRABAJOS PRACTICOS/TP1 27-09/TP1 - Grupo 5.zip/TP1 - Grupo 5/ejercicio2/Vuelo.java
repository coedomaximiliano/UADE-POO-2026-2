package tp1.ejercicio2;

import java.time.LocalDate;

public class Vuelo {

    private int numero;
    private LocalDate fecha;
    private int lugaresDisponibles;
    private Ciudad destino;

    public Vuelo(int numero, LocalDate fecha, int lugaresDisponibles, Ciudad destino) {
        this.numero = numero;
        this.fecha = fecha;
        this.lugaresDisponibles = lugaresDisponibles;
        this.destino = destino;
    }

    public int getNumero() {
        return numero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public Ciudad getDestino() {
        return destino;
    }

    public int getLugaresDisponibles() {
        return lugaresDisponibles;
    }

    public boolean hayDisponibilidad() {
        return lugaresDisponibles > 0;
    }

    public void reservarLugar() {
        if (hayDisponibilidad()) {
            lugaresDisponibles--;
        }
    }
}