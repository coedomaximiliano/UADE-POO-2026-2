package ejercicio1;

public class Agenda {
    /// ATRIBUTOS
    private String lugarReunion;
    private String participantes;
    private String temaReunion;
    private Double duracion;

    /// CONSTRUCTOR VACIO
    public Agenda() {}

    /// CONSTRUCTOR DE LA CLASE QUE RECIBE PARAMETROS
    public Agenda(String lugarReunion_, String participantes_, String temaReunion_, Double duracion_){
        this.lugarReunion = lugarReunion_;
        this.participantes = participantes_;
        this.temaReunion = temaReunion_;
        this.duracion = duracion_;
    }

    /// METODOS GETTERS
    public String getLugarReunion() {
        return lugarReunion;
    }

    public String getParticipantes() {
        return participantes;
    }

    public String getTemaReunion() {
        return temaReunion;
    }

    public Double getDuracion() {
        return duracion;
    }

    
    ///METODOS SETTERS
    public void setLugarReunion(String lugarReunion) {
        this.lugarReunion = lugarReunion;
    }

    public void setParticipantes(String participantes) {
        this.participantes = participantes;
    }

    public void setTemaReunion(String temaReunion) {
        this.temaReunion = temaReunion;
    }

    public void setDuracion(Double duracion) {
        this.duracion = duracion;
    }

    @Override
    public String toString() {
        return "ejercicio1.Agenda " +
                "lugarReunion= '" + lugarReunion + '\'' +
                ", participantes= '" + participantes + '\'' +
                ", temaReunion= '" + temaReunion + '\'' +
                ", duracion= '" + duracion + '\'';
    }
}
