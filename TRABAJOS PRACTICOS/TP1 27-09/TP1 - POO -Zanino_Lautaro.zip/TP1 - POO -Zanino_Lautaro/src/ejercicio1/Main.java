package ejercicio1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el lugar de la reunión:");
        String lugar = scanner.nextLine();

        System.out.println("Ingrese los participantes de la reunión:");
        String participantes = scanner.nextLine();

        System.out.println("Ingrese el tema de la reunión:");
        String temaReunion = scanner.nextLine();

        System.out.println("Ingrese la duración de la reunión (use punto, ej: 1.45):");
        Double duracion = scanner.nextDouble();

        Agenda agenda = new Agenda(lugar, participantes, temaReunion, duracion);

        System.out.println("\n --- DATOS INGRESADOS ---");
        System.out.println("Lugar de la reunion: " + agenda.getLugarReunion());
        System.out.println("Participantes: " + agenda.getParticipantes());
        System.out.println("Tema de la reunion: " + agenda.getTemaReunion());
        System.out.println("Duracion de la reunion: " + agenda.getDuracion());

        scanner.close();
    }
}