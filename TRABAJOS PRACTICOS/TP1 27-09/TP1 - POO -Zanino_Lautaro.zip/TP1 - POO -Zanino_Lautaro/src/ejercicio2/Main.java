package ejercicio2;

import java.time.LocalDate;
import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {

        /// Creo el Vuelo con datos de prueba, usando el constructor con parámetros
        Vuelo vuelo = new Vuelo(
                "AA1234",                          // numeroDeVuelo
                "Miami",                            // destino
                "American Airlines",                // aerolinea
                LocalDate.of(2026, 3, 15),          // fecha
                LocalTime.of(10, 30),               // horaSalida
                LocalTime.of(18, 45),               // horaLlegada
                40,                                  // lugaresDisponibles
                Vuelo.Categoria.BUSINESS,            // categoria (enum)
                Vuelo.Seccion.NO_FUMADORES          // seccion (enum)
        );

        /// Creo el Pasajero con datos de prueba
        Pasajero pasajero = new Pasajero(
                "Juan",      // nombre
                "Perez",       // apellido
                40123456,       // dni
                "AAA123456"     // pasaporte
        );

        /// Creo la Reserva, pasándole los objetos vuelo y pasajero ya creados
        Reserva reserva = new Reserva(vuelo, pasajero);

        /// Imprimo los datos usando los getters
        System.out.println("\n --- INFORMACION DE LA RESERVA ---");
        System.out.println("Pasajero: " + pasajero.getNombre() + " " + pasajero.getApellido());
        System.out.println("Vuelo: " + vuelo.getNumeroDeVuelo() + " a " + vuelo.getDestino());
        System.out.println("Categoria: " + vuelo.getCategoria());
        System.out.println("Reserva - Vuelo asociado: " + reserva.getNumeroDeVuelo().getNumeroDeVuelo());
        System.out.println("Reserva - Pasajero asociado: " + reserva.getDni().getNombre());
    }
}