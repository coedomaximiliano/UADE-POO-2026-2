package ejercicio2;

public class Pasajero {

    ///CONSTRUCTOR
    public Pasajero() {}

    ///CONSTRUCTOR CON PARAMETROS
    public Pasajero(String nombre, String apellido, int dni, String pasaporte) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.pasaporte = pasaporte;
    }

    ///ATRIBUTOS
    private String nombre;
    private String apellido;
    private int dni;
    private String pasaporte;

    ///GETTERS
    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getDni() {
        return dni;
    }

    public String getPasaporte() {
        return pasaporte;
    }


    ///SETTERS
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public void setPasaporte(String pasaporte) {
        this.pasaporte = pasaporte;
    }
}
