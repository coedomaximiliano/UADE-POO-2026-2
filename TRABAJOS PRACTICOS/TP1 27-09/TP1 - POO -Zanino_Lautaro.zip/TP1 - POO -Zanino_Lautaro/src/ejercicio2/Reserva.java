package ejercicio2;

public class Reserva {

    ///ATRIBUTOS
     private Vuelo numeroDeVuelo;
     private Pasajero dni;

     ///CONSTRUCTOR
    public Reserva() {}

    ///CONSTRUCTOR CON PARAMETROS
    public Reserva(Vuelo numeroDeVuelo, Pasajero dni) {
        this.numeroDeVuelo = numeroDeVuelo;
        this.dni = dni;
    }

    ///GETTERS
    public Vuelo getNumeroDeVuelo() {
        return numeroDeVuelo;
    }

    public Pasajero getDni() {
        return dni;
    }

    ///SETTERS
    public void setNumeroDeVuelo(Vuelo numeroDeVuelo) {
        this.numeroDeVuelo = numeroDeVuelo;
    }

    public void setDni(Pasajero dni) {
        this.dni = dni;
    }
}
