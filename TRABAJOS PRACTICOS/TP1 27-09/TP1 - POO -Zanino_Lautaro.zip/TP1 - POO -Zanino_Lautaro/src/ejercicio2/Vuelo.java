package ejercicio2;

import java.time.LocalDate;
import java.time.LocalTime;


public class Vuelo {

    ///ENUMS
    public enum Categoria {
        ECONOMICA,
        ECONOMICA_PREMIUM,
        PRIMERA_CLASE,
        BUSINESS
    }

    public enum Seccion {
        FUMADORES,
        NO_FUMADORES
    }

    ///ATRIBUTOS
    private String numeroDeVuelo;
    private String destino;
    private String aerolinea;
    private LocalDate fecha;
    private LocalTime horaSalida;
    private LocalTime horaLlegada;
    private int lugaresDisponibles;
    private Categoria categoria;
    private Seccion seccion;

    ///CONSTRUCTOR VACIO
    public Vuelo() {}

    ///CONSTRUCTOR CON PARAMETROS
    public Vuelo(String numeroDeVuelo, String destino, String aerolinea, LocalDate fecha,
                 LocalTime horaSalida, LocalTime horaLlegada, int lugaresDisponibles,
                 Categoria categoria, Seccion seccion) {
        this.numeroDeVuelo = numeroDeVuelo;
        this.destino = destino;
        this.aerolinea = aerolinea;
        this.fecha = fecha;
        this.horaSalida = horaSalida;
        this.horaLlegada = horaLlegada;
        this.lugaresDisponibles = lugaresDisponibles;
        this.categoria = categoria;
        this.seccion = seccion;
    }

    ///GETTERS
    public String getNumeroDeVuelo() {
        return numeroDeVuelo;
    }

    public String getDestino() {
        return destino;
    }

    public String getAerolinea() {
        return aerolinea;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public LocalTime getHoraSalida() {
        return horaSalida;
    }

    public LocalTime getHoraLlegada() {
        return horaLlegada;
    }

    public int getLugaresDisponibles() {
        return lugaresDisponibles;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public Seccion getSeccion() {
        return seccion;
    }

    ///SETTERS
    public void setNumeroDeVuelo(String numeroDeVuelo) {
        this.numeroDeVuelo = numeroDeVuelo;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public void setAerolinea(String aerolinea) {
        this.aerolinea = aerolinea;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setHoraSalida(LocalTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    public void setHoraLlegada(LocalTime horaLlegada) {
        this.horaLlegada = horaLlegada;
    }

    public void setLugaresDisponibles(int lugaresDisponibles) {
        this.lugaresDisponibles = lugaresDisponibles;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public void setSeccion(Seccion seccion) {
        this.seccion = seccion;
    }
}