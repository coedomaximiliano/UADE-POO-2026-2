package Ejercicio1;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

public class GestorCompras {

    private Scanner scanner;

    ///ATRIBUTOS
    private ArrayList<Producto> productos;
    private ArrayList<OrdenDeCompra> ordenDeCompra;
    private ArrayList<Proveedor> proveedores;

    ///CONSTRUCTOR
    public GestorCompras(Scanner scanner) {
        this.scanner = scanner;
        this.productos = new ArrayList<>();
        this.ordenDeCompra = new ArrayList<>();
        this.proveedores = new ArrayList<>();
    }

    ///METODOS
    public void agregarProveedor(){
        System.out.println("Ingrese el dni del proveedor: ");
        int dni = scanner.nextInt();
        scanner.nextLine();

        boolean existe = false;
        for (Proveedor prov : proveedores) {
            if (prov.getDni() == dni) {
                existe = true;
            }
        }

        if (existe) {
            System.out.println("Ya existe un proveedor con ese dni.");
            return;
        }

        System.out.println("Ingrese el nombre del proveedor: ");
        String nombre = scanner.nextLine();

        Proveedor proveedor = new Proveedor(dni, nombre);
        proveedores.add(proveedor);
        System.out.println("Proveedor agregado correctamente.");
    }

    public void agregarProducto(){
        System.out.println("Ingrese el codigo del producto: ");
        String codigo = scanner.nextLine();

        boolean existe = false;
        for (Producto p : productos) {
            if (p.getCodigo().equals(codigo)) {
                existe = true;
            }
        }

        if (existe) {
            System.out.println("Ya existe un producto con ese código.");
            return;
        }

        System.out.println("Ingrese el nombre del Producto: ");
        String descripcion = scanner.nextLine();

        System.out.println("Ingrese el precio del producto: ");
        Double precio = scanner.nextDouble();

        Producto nuevoProducto = new Producto(codigo, descripcion, precio);
        productos.add(nuevoProducto);
        System.out.println("Producto agregado correctamente.");
    }

    public void generarOrdenDeCompra(){

        System.out.println("Ingrese el dni del Proveedor: ");
        int dni = scanner.nextInt();
        scanner.nextLine();

        Proveedor proveedorEncontrado = null;
        for (Proveedor p : proveedores) {
            if (p.getDni() == dni) {
                proveedorEncontrado = p;
            }
        }

        if (proveedorEncontrado == null) {
            System.out.println("Proveedor no encontrado.");
            return;
        }

        System.out.println("Ingrese el año de la compra: ");
        int anio = scanner.nextInt();

        System.out.println("Ingrese el mes de la compra: ");
        int mes = scanner.nextInt();

        System.out.println("Ingrese el día de la compra: ");
        int dia = scanner.nextInt();
        scanner.nextLine();

        LocalDate fecha = LocalDate.of(anio, mes, dia);

        System.out.println("Ingrese el código del producto: ");
        String codigoProducto = scanner.nextLine();

        Producto productoEncontrado = null;
        for (Producto p : productos) {
            if (p.getCodigo().equals(codigoProducto)) {
                productoEncontrado = p;
            }
        }

        if (productoEncontrado == null) {
            System.out.println("Producto no encontrado.");
            return;
        }

        System.out.println("Ingrese la cantidad a comprar: ");
        int cantidad = scanner.nextInt();

        String numero = String.valueOf(ordenDeCompra.size() + 1);

        OrdenDeCompra nuevaOrden = new OrdenDeCompra(numero, proveedorEncontrado, productoEncontrado, fecha, cantidad);
        ordenDeCompra.add(nuevaOrden);

        System.out.println("Orden de compra generada correctamente. Número: " + numero);
    }

    public void consultarOrdenesDeCompra(){
        System.out.println("Ingrese el dni del proveedor: ");
        int dni = scanner.nextInt();
        scanner.nextLine();

        Proveedor proveedorEncontrado = null;
        for (Proveedor p : proveedores) {
            if (p.getDni() == dni) {
                proveedorEncontrado = p;
            }
        }

        if (proveedorEncontrado == null) {
            System.out.println("Proveedor no encontrado.");
            return;
        }

        double total = 0;

        for (OrdenDeCompra orden : ordenDeCompra) {
            if (orden.getProveedor().getDni() == dni ) {
                total += orden.getProducto().getPrecio() * orden.getCantidad();
            }
        }

        System.out.println("Proveedor: " + proveedorEncontrado.getNombre());
        System.out.println("Total de órdenes de compra: " + total);
    }
}