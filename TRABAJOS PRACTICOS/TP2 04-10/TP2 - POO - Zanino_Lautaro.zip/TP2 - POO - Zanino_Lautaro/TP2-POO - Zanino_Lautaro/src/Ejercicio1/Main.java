package Ejercicio1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        GestorCompras gestor = new GestorCompras(scanner);

        int opcion;

        do {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Agregar proveedor");
            System.out.println("2. Agregar producto");
            System.out.println("3. Generar orden de compra");
            System.out.println("4. Consultar ordenes de compra por proveedor");
            System.out.println("0. Salir");
            System.out.println("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    gestor.agregarProveedor();
                    break;
                case 2:
                    gestor.agregarProducto();
                    break;
                case 3:
                    gestor.generarOrdenDeCompra();
                    break;
                case 4:
                    gestor.consultarOrdenesDeCompra();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 0);

        scanner.close();
    }
}