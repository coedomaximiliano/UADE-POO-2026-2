package Ejercicio1;

import java.time.LocalDate;

public class OrdenDeCompra {

    ///CONSTRUCTOR
    public OrdenDeCompra() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public OrdenDeCompra(String numero, Proveedor proveedor, Producto producto, LocalDate fecha, int cantidad) {
        this.numero = numero;
        this.proveedor = proveedor;
        this.producto = producto;
        this.fecha = fecha;
        this.cantidad = cantidad;
    }

    ///ATRIBUTOS
    private String numero;
    private Proveedor proveedor;
    private Producto producto;
    private LocalDate fecha;
    private int cantidad;

    ///GETTERS
    public String getNumero() {
        return numero;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public Producto getProducto() {
        return producto;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public int getCantidad() {
        return cantidad;
    }

    ///SETTERS
    public void setNumero(String numero) { this.numero = numero; }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
}
