package Ejercicio1;

public class Producto {
    ///CONSTRUCTOR
    public Producto() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Producto(String codigo, String descripcion, Double precio) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    ///ATRIBUTOS
    private String codigo;
    private String descripcion;
    private Double precio;

    ///GETTERS
    public String getCodigo() {
        return codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public Double getPrecio() {
        return precio;
    }

    ///SETTERS
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }
}
