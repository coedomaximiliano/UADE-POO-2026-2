package Ejercicio1;

public class Proveedor {
    ///CONSTRUCTOR
    public Proveedor() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Proveedor(int dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
    }

    ///ATRIBUTOS
    private int dni;
    private String nombre;

    ///GETTERS
    public int getDni() { return dni; }

    public String getNombre() {
        return nombre;
    }

    ///SETTERS
    public void setDni(int dni) { this.dni = dni; }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
