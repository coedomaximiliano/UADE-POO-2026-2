package Ejercicio2;

import java.util.ArrayList;

public class Aerolinea {

    ///ATRIBUTOS
    private String codigo;
    private String nombre;
    private ArrayList<Vuelo> vuelos;

    ///CONSTRUCTOR
    public Aerolinea() {
        this.vuelos = new ArrayList<>();
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Aerolinea(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.vuelos = new ArrayList<>();
    }

    ///GETTERS
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<Vuelo> getVuelos() {
        return vuelos;
    }

    ///SETTERS
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setVuelos(ArrayList<Vuelo> vuelos) {
        this.vuelos = vuelos;
    }
}