package Ejercicio2;

public class Aeropuerto {

    ///ATRIBUTOS
    private String codigoDeAeropuerto;
    private String nombre;
    private Ciudad ciudad;

    ///CONSTRUCTOR
    public Aeropuerto() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Aeropuerto(String codigoDeAeropuerto, String nombre, Ciudad ciudad) {
        this.codigoDeAeropuerto = codigoDeAeropuerto;
        this.nombre = nombre;
        this.ciudad = ciudad;
    }

    ///GETTERS
    public String getCodigoDeAeropuerto() {
        return codigoDeAeropuerto;
    }

    public String getNombre() {
        return nombre;
    }

    public Ciudad getCiudad() {
        return ciudad;
    }

    ///SETTERS
    public void setCodigoDeAeropuerto(String codigoDeAeropuerto) {
        this.codigoDeAeropuerto = codigoDeAeropuerto;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCiudad(Ciudad ciudad) {
        this.ciudad = ciudad;
    }
}