package Ejercicio2;

public class Avion {

    ///ATRIBUTOS
    private String codigoAvion;
    private String nombre;
    private int cantidadAsientos;

    ///CONSTRUCTOR
    public Avion() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Avion(String codigoAvion, String nombre, int cantidadAsientos) {
        this.codigoAvion = codigoAvion;
        this.nombre = nombre;
        this.cantidadAsientos = cantidadAsientos;
    }

    ///GETTERS
    public String getCodigoAvion() {
        return codigoAvion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getCantidadAsientos() {
        return cantidadAsientos;
    }

    ///SETTERS
    public void setCodigoAvion(String codigoAvion) {
        this.codigoAvion = codigoAvion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCantidadAsientos(int cantidadAsientos) {
        this.cantidadAsientos = cantidadAsientos;
    }
}