package Ejercicio2;

public class Boleto {

    ///ATRIBUTOS
    private Pasajero pasajero;
    private Vuelo vuelo;
    private String asiento;

    ///CONSTRUCTOR
    public Boleto() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Boleto(Pasajero pasajero, Vuelo vuelo, String asiento) {
        this.pasajero = pasajero;
        this.vuelo = vuelo;
        this.asiento = asiento;
    }

    ///GETTERS
    public Pasajero getPasajero() { return pasajero; }

    public Vuelo getVuelo() {
        return vuelo;
    }

    public String getAsiento() {
        return asiento;
    }

    ///SETTERS
    public void setPasajero(Pasajero pasajero) {
        this.pasajero = pasajero;
    }

    public void setVuelo(Vuelo vuelo) {
        this.vuelo = vuelo;
    }

    public void setAsiento(String asiento) {
        this.asiento = asiento;
    }
}