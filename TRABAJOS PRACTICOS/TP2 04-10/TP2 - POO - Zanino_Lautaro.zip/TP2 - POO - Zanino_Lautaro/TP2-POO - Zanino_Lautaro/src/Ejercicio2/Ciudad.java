package Ejercicio2;

public class Ciudad {

    ///ATRIBUTOS
    private String codigoDeCiudad;
    private String nombre;
    private String pais;

    ///CONSTRUCTOR
    public Ciudad() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Ciudad(String codigoDeCiudad, String nombre, String pais) {
        this.codigoDeCiudad = codigoDeCiudad;
        this.nombre = nombre;
        this.pais = pais;
    }

    ///GETTERS
    public String getCodigoDeCiudad() {
        return codigoDeCiudad;
    }

    public String getNombre() {
        return nombre;
    }

    public String getPais() {
        return pais;
    }

    ///SETTERS
    public void setCodigoDeCiudad(String codigoDeCiudad) {
        this.codigoDeCiudad = codigoDeCiudad;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }
}