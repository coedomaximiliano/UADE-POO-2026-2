package Ejercicio2;

import Ejercicio1.Proveedor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Scanner;

public class GestorAerolinea {

    private Scanner scanner;

    /// ATRIBUTOS
    private ArrayList<Ciudad> ciudades;
    private ArrayList<Vuelo> vuelos;
    private ArrayList<Aeropuerto> aeropuertos;
    private ArrayList<Tripulante> tripulantes;
    private ArrayList<Avion> aviones;

    /// CONSTRUCTOR
    public GestorAerolinea(Scanner scanner) {
        this.scanner = scanner;
        this.ciudades = new ArrayList<>();
        this.vuelos = new ArrayList<>();
        this.aeropuertos = new ArrayList<>();
        this.tripulantes = new ArrayList<>();
        this.aviones = new ArrayList<>();
    }

    public void agregarCiudad() {

        System.out.println("INGRESE EL CODIGO DE LA CIUDAD: ");
        String codigo = scanner.nextLine();

        boolean existe = false;
        for (Ciudad c : ciudades) {
            if (c.getCodigoDeCiudad().equals(codigo)) {
                existe = true;
            }
        }

        if(existe) {
            System.out.println("YA EXISTE UNA CIUDAD CON ESE CODIGO");
            return;
        }

        System.out.println("INGRESE NOMBRE DE LA CIUDAD: ");
        String nombre = scanner.nextLine();

        System.out.println("INGRESE EL PAIS DONDE SE ENCUENTRA LA CIUDAD: ");
        String pais = scanner.nextLine();

        Ciudad ciudad = new Ciudad(codigo, nombre, pais);
        ciudades.add(ciudad);
        System.out.println("CIUDAD AGREGADA CORRECTAMENTE");
    }

    public void agregarAeropuerto() {

        System.out.println("INGRESE EL CODIGO DE LA CIUDAD DONDE SE ENCUENTRA EL AEROPUERTO: ");
        String codigoCiudad = scanner.nextLine();

        Ciudad ciudadEncontrada = null;
        for (Ciudad c : ciudades) {
            if (c.getCodigoDeCiudad().equals(codigoCiudad)) {
                ciudadEncontrada = c;
            }
        }

        if (ciudadEncontrada == null) {
            System.out.println("NO EXISTE UNA CIUDAD CON ESE CODIGO. DEBE CARGARLA PRIMERO.");
            return;
        }

        System.out.println("INGRESE EL CODIGO DEL AEROPUERTO: ");
        String codigoAeropuerto = scanner.nextLine();

        boolean existe = false;
        for (Aeropuerto a : aeropuertos) {
            if (a.getCodigoDeAeropuerto().equals(codigoAeropuerto)) {
                existe = true;
            }
        }

        if (existe) {
            System.out.println("YA EXISTE UN AEROPUERTO CON ESE CODIGO");
            return;
        }

        System.out.println("INGRESE EL NOMBRE DEL AEROPUERTO: ");
        String nombre = scanner.nextLine();

        Aeropuerto aero = new Aeropuerto(codigoAeropuerto, nombre, ciudadEncontrada);
        aeropuertos.add(aero);
        System.out.println("AEROPUERTO AGREGADO CORRECTAMENTE");
    }

    public void agregarAvion(){

        System.out.println("INGRESE EL CODIGO DEL AVION: ");
        String codigo = scanner.nextLine();

        boolean existe = false;
        for (Avion a : aviones) {
            if (a.getCodigoAvion().equals(codigo)) {
                existe = true;
            }
        }

        if(existe) {
            System.out.println("YA EXISTE UN AVION CON ESE CODIGO");
            return;
        }

        System.out.println("INGRESE NOMBRE DEL AVION: ");
        String nombre = scanner.nextLine();

        System.out.println("INGRESE LA CANTIDAD DE ASIETOS DEL AVION: ");
        int asientos = scanner.nextInt();
        scanner.nextLine();

        Avion a = new Avion(codigo, nombre, asientos);
        aviones.add(a);
        System.out.println("AVION CARGADO CORRECTAMENTE.");
    }

    public void agregarTripulante(){

        System.out.println("INGRESE EL DNI DEL TRIPULANTE: ");
        int dni = scanner.nextInt();
        scanner.nextLine();

        boolean existe = false;
        for (Tripulante t : tripulantes) {
            if (t.getDni() == dni) {
                existe = true;
            }
        }

        if (existe) {
            System.out.println("YA EXISTE UN TRIPULANTE CON ESE DNI");
            return;
        }

        System.out.println("INGRESE NOMBRE DEL TRIPULANTE: ");
        String nombre = scanner.nextLine();

        System.out.println("INGRESE APELLIDO DEL TRIPULANTE: ");
        String apellido = scanner.nextLine();

        System.out.println("SELECCIONE EL REOL DEL TRIPULANTE:");
        System.out.println("1. Piloto");
        System.out.println("2. Azafata");
        System.out.println("3. Comisario");
        System.out.println("4. Operador de comunicaciones");
        int opcionRol = scanner.nextInt();
        scanner.nextLine();

        RolTripulante rol = null;
        if (opcionRol == 1) {
            rol = RolTripulante.PILOTO;
        } else if (opcionRol == 2) {
            rol = RolTripulante.AZAFATA;
        } else if (opcionRol == 3) {
            rol = RolTripulante.COMISARIO;
        } else if (opcionRol == 4) {
            rol = RolTripulante.OPERADOR_COMUNICACIONES;
        }

        Tripulante tri = new Tripulante(dni, nombre, apellido, rol);
        tripulantes.add(tri);
        System.out.println("TRIPULANTE CARGADO CORRECTAMENTE");
    }

    public void agregarVuelo() {

        System.out.println("INGRESE EL NUMERO DE VUELO: ");
        String numeroDeVuelo = scanner.nextLine();

        System.out.println("INGRESE EL CODIGO DEL AEROPUERTO DE ORIGEN: ");
        String codigoOrigen = scanner.nextLine();

        Aeropuerto aeropuertoOrigenEncontrado = null;
        for (Aeropuerto a : aeropuertos) {
            if (a.getCodigoDeAeropuerto().equals(codigoOrigen)) {
                aeropuertoOrigenEncontrado = a;
            }
        }

        if (aeropuertoOrigenEncontrado == null) {
            System.out.println("NO SE ENCONTRO UN AEROPUERTO CON ESE CODIGO");
            return;
        }

        System.out.println("INGRESE EL CODIGO DEL AEROPUERTO DE DESTINO: ");
        String codigoDestino = scanner.nextLine();

        if (codigoDestino.equals(codigoOrigen)) {
            System.out.println("NO SE PUEDE REPETIR EL MISMO CODIGO QUE EL AEROPUERTO DE ORIGEN");
            return;
        }

        Aeropuerto aeropuertoDestinoEncontrado = null;
        for (Aeropuerto a : aeropuertos) {
            if (a.getCodigoDeAeropuerto().equals(codigoDestino)) {
                aeropuertoDestinoEncontrado = a;
            }
        }

        if (aeropuertoDestinoEncontrado == null) {
            System.out.println("NO SE ENCONTRO UN AEROPUERTO CON ESE CODIGO");
            return;
        }

        System.out.println("INGRESE EL CODIGO DEL AVION: ");
        String codigoAvion = scanner.nextLine();

        Avion avionEncontrado = null;
        for (Avion a : aviones) {
            if (a.getCodigoAvion().equals(codigoAvion)) {
                avionEncontrado = a;
            }
        }

        if (avionEncontrado == null) {
            System.out.println("NO SE ENCONTRO UN AVION CON ESE CODIGO");
            return;
        }

        System.out.println("INGRESE EL AÑO DE LA FECHA DEL VUELO: ");
        int anio = scanner.nextInt();

        System.out.println("INGRESE EL MES DE LA FECHA DEL VUELO: ");
        int mes = scanner.nextInt();

        System.out.println("INGRESE EL DIA DE LA FECHA DEL VUELO: ");
        int dia = scanner.nextInt();

        LocalDate fecha = LocalDate.of(anio, mes, dia);

        System.out.println("INGRESE LA HORA DE SALIDA (formato 24hs, hora): ");
        int horaSalidaHs = scanner.nextInt();

        System.out.println("INGRESE LOS MINUTOS DE SALIDA: ");
        int horaSalidaMin = scanner.nextInt();

        LocalTime horaSalida = LocalTime.of(horaSalidaHs, horaSalidaMin);

        System.out.println("INGRESE LA HORA DE LLEGADA (formato 24hs, hora): ");
        int horaLlegadaHs = scanner.nextInt();

        System.out.println("INGRESE LOS MINUTOS DE LLEGADA: ");
        int horaLlegadaMin = scanner.nextInt();

        LocalTime horaLlegada = LocalTime.of(horaLlegadaHs, horaLlegadaMin);
        scanner.nextLine();

        Vuelo vuelo = new Vuelo(numeroDeVuelo, fecha, horaSalida, horaLlegada, aeropuertoOrigenEncontrado, aeropuertoDestinoEncontrado, avionEncontrado);
        vuelos.add(vuelo);

        System.out.println("VUELO AGREGADO CORRECTAMENTE.");
    }

}