package Ejercicio2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        GestorAerolinea gestor = new GestorAerolinea(scanner);

        int opcion;

        do {
            System.out.println("\n===== MENU AEROLINEA =====");
            System.out.println("1. Agregar ciudad");
            System.out.println("2. Agregar aeropuerto");
            System.out.println("3. Agregar avion");
            System.out.println("4. Agregar tripulante");
            System.out.println("5. Agregar vuelo");
            System.out.println("0. Salir");
            System.out.println("Ingrese una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    gestor.agregarCiudad();
                    break;
                case 2:
                    gestor.agregarAeropuerto();
                    break;
                case 3:
                    gestor.agregarAvion();
                    break;
                case 4:
                    gestor.agregarTripulante();
                    break;
                case 5:
                    gestor.agregarVuelo();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }

        } while (opcion != 0);

        scanner.close();
    }
}