package Ejercicio2;

public class Pasajero {

    ///ATRIBUTOS
    private int dni;
    private String nombre;
    private String apellido;
    private String pasaporte;

    ///CONSTRUCTOR
    public Pasajero() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Pasajero(int dni, String nombre, String apellido, String pasaporte) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.pasaporte = pasaporte;
    }

    ///GETTERS
    public int getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getPasaporte() {
        return pasaporte;
    }

    ///SETTERS
    public void setDni(int dni) {
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setPasaporte(String pasaporte) {
        this.pasaporte = pasaporte;
    }
}