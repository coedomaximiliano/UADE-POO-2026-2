package Ejercicio2;

public enum RolTripulante {
    PILOTO,
    AZAFATA,
    COMISARIO,
    OPERADOR_COMUNICACIONES
}