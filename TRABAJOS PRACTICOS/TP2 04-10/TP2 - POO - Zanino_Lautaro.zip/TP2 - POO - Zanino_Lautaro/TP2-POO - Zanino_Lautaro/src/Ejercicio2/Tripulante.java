package Ejercicio2;

public class Tripulante {

    ///ATRIBUTOS
    private int dni;
    private String nombre;
    private String apellido;
    private RolTripulante rol;

    ///CONSTRUCTOR
    public Tripulante() {
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Tripulante(int dni, String nombre, String apellido, RolTripulante rol) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.rol = rol;
    }

    ///GETTERS
    public int getDni() {
        return dni;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public RolTripulante getRol() {
        return rol;
    }

    ///SETTERS
    public void setDni(int dni) {
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setRol(RolTripulante rol) {
        this.rol = rol;
    }
}