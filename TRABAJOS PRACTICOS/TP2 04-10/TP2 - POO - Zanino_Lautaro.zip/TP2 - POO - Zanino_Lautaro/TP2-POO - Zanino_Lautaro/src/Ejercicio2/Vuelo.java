package Ejercicio2;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;

public class Vuelo {

    ///ATRIBUTOS
    private String numeroDeVuelo;
    private LocalDate fecha;
    private LocalTime horaSalida;
    private LocalTime horaLlegada;
    private Aeropuerto aeropuertoOrigen;
    private Aeropuerto aeropuertoDestino;
    private ArrayList<Aeropuerto> escalas;
    private Avion avion;
    private ArrayList<Tripulante> tripulacion;

    ///CONSTRUCTOR
    public Vuelo() {
        this.escalas = new ArrayList<>();
        this.tripulacion = new ArrayList<>();
    }

    ///CONSTRUCTOR CON PARAMETROS
    public Vuelo(String numeroDeVuelo, LocalDate fecha, LocalTime horaSalida, LocalTime horaLlegada,
                 Aeropuerto aeropuertoOrigen, Aeropuerto aeropuertoDestino, Avion avion) {
        this.numeroDeVuelo = numeroDeVuelo;
        this.fecha = fecha;
        this.horaSalida = horaSalida;
        this.horaLlegada = horaLlegada;
        this.aeropuertoOrigen = aeropuertoOrigen;
        this.aeropuertoDestino = aeropuertoDestino;
        this.avion = avion;
        this.escalas = new ArrayList<>();
        this.tripulacion = new ArrayList<>();
    }

    ///GETTERS
    public String getNumeroDeVuelo() {
        return numeroDeVuelo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public LocalTime getHoraSalida() {
        return horaSalida;
    }

    public LocalTime getHoraLlegada() {
        return horaLlegada;
    }

    public Aeropuerto getAeropuertoOrigen() {
        return aeropuertoOrigen;
    }

    public Aeropuerto getAeropuertoDestino() {
        return aeropuertoDestino;
    }

    public ArrayList<Aeropuerto> getEscalas() {
        return escalas;
    }

    public Avion getAvion() {
        return avion;
    }

    public ArrayList<Tripulante> getTripulacion() {
        return tripulacion;
    }

    ///SETTERS
    public void setNumeroDeVuelo(String numeroDeVuelo) {
        this.numeroDeVuelo = numeroDeVuelo;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }

    public void setHoraSalida(LocalTime horaSalida) {
        this.horaSalida = horaSalida;
    }

    public void setHoraLlegada(LocalTime horaLlegada) {
        this.horaLlegada = horaLlegada;
    }

    public void setAeropuertoOrigen(Aeropuerto aeropuertoOrigen) {
        this.aeropuertoOrigen = aeropuertoOrigen;
    }

    public void setAeropuertoDestino(Aeropuerto aeropuertoDestino) {
        this.aeropuertoDestino = aeropuertoDestino;
    }

    public void setEscalas(ArrayList<Aeropuerto> escalas) {
        this.escalas = escalas;
    }

    public void setAvion(Avion avion) {
        this.avion = avion;
    }

    public void setTripulacion(ArrayList<Tripulante> tripulacion) {
        this.tripulacion = tripulacion;
    }
}