import java.time.Year;
import java.util.Scanner;

public class Automovil {

    ///ATRIBUTOS
    private String marca;
    private Year modelo;
    private Double motor;
    private TipoCombustible tipoCombustible;
    private TipoAutomovil tipoAutomovil;
    private int cantPuertas;
    private int cantAsientos;
    private int velocidadMax;
    private Color color;
    private int velocidadActual;
    private boolean esAutomatico = true;
    private double totalMultas;

    ///CONSTRUCTOR
    public Automovil(String marca, Year modelo, Double motor, TipoCombustible tipoCombustible, TipoAutomovil tipoAutomovil, int cantPuertas, int cantAsientos, int velocidadMax, Color color) {
        this.marca = marca;
        this.modelo = modelo;
        this.motor = motor;
        this.tipoCombustible = tipoCombustible;
        this.tipoAutomovil = tipoAutomovil;
        this.cantPuertas = cantPuertas;
        this.cantAsientos = cantAsientos;
        this.velocidadMax = velocidadMax;
        this.color = color;
        this.velocidadActual = 0;
        this.esAutomatico = true;
        this.totalMultas = 0;
    }

    ///GETTERS
    public String getMarca() {
        return marca;
    }

    public Year getModelo() { return modelo; }

    public Double getMotor() {
        return motor;
    }

    public TipoCombustible getTipoCombustible() {
        return tipoCombustible;
    }

    public TipoAutomovil getTipoAutomovil() {
        return tipoAutomovil;
    }

    public int getCantPuertas() {
        return cantPuertas;
    }

    public int getCantAsientos() {
        return cantAsientos;
    }

    public int getVelocidadMax() {
        return velocidadMax;
    }

    public Color getColor() {
        return color;
    }

    public int getVelocidadActual(){
        return velocidadActual;
    }

    public boolean isEsAutomatico() { return esAutomatico; }

    public double getTotalMultas() { return totalMultas; }

    ///SETTERS
    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(Year modelo) {
        this.modelo = modelo;
    }

    public void setMotor(Double motor) {
        this.motor = motor;
    }

    public void setTipoCombustible(TipoCombustible tipoCombustible) {
        this.tipoCombustible = tipoCombustible;
    }

    public void setTipoAutomovil(TipoAutomovil tipoAutomovil) { this.tipoAutomovil = tipoAutomovil; }

    public void setCantPuertas(int cantPuertas) { this.cantPuertas = cantPuertas; }

    public void setCantAsientos(int cantAsientos) { this.cantAsientos = cantAsientos; }

    public void setVelocidadMax(int velocidadMax) {
        this.velocidadMax = velocidadMax;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public void setEsAutomatico(boolean esAutomatico) { this.esAutomatico = esAutomatico; }

    ///METODOS
//    public void acelerar(int kilometros) {
//        int nuevaVelocidad = velocidadActual + kilometros;
//
//        if (nuevaVelocidad > velocidadMax) {
//            System.out.println("NO SE PUEDE ACELERAR MAS QUE LA VELOCIDAD MAXIMA");
//            velocidadActual = velocidadMax;
//        } else {
//            velocidadActual = nuevaVelocidad;
//        }
//    }

    public void acelerar(int kilometros){
        int nuevaVelocidad = velocidadActual + kilometros;
        final double multa = 100000.00;

        if (nuevaVelocidad > velocidadMax) {
            totalMultas +=  multa;
            System.out.println("\nSE LE HIZO UNA MULTA POR " + multa + " POR HABER EXCEDIDO EL LIMITE DE VELOCIDAD");
        }
        else {
            System.out.println("else DEL METODO ACELERAR");
            velocidadActual = nuevaVelocidad;
        }
    }

    public boolean tieneMultas() {
        return totalMultas > 0;
    }

    public void desacelerar(int kilometros) {
        int nuevaVelocidad = velocidadActual - kilometros;

        if (nuevaVelocidad < 0) {
            System.out.println("\nLA VELOCIDAD DEBE SER MAYOR O IGUAL A CERO");
            velocidadActual = 0;
        } else {
            System.out.println("else DEL METODO DESACELERAR");
            velocidadActual = nuevaVelocidad;
        }
    }

    public void frenar() {
        velocidadActual = 0;
        System.out.println("\nEL VEHICULO ESTA FRENADO");
    }

    public void calcularTiempoEstimado(double distanciaKm) {
        if (velocidadActual == 0) {
            System.out.println("EL VEHICULO ESTA DETENIDO, NO SE PUEDE CALCULAR EL TIEMPO ESTIMADO");
            return;
        }

        double tiempoEstimado = distanciaKm / velocidadActual;
        System.out.println("TIEMPO ESTIMADO DE LLEGADA: " + tiempoEstimado + " horas");
    }

    public void mostrarValoresPantalla() {
        System.out.println("LA MARCA DEL AUTO ES " + marca);
        System.out.println("EL MODELO DEL AUTO ES " + modelo);
        System.out.println("EL AUTO TIENE UN MOTOR " + motor);
        System.out.println("EL AUTO USA " + tipoCombustible + " COMO COMBUSTIBLE");
        System.out.println("EL AUTO ES UN " + tipoAutomovil);
        System.out.println("EL AUTO TIENE " + cantPuertas + " PUERTAS");
        System.out.println("EL AUTO TIENE " + cantAsientos + " ASIENTOS");
        System.out.println("SU VELOCIDAD MAXIMA ES DE " + velocidadMax + " KM/H");
        System.out.println("LA VELOCIDAD ACTUAL ES DE " + velocidadActual + " KM/H");
        System.out.println("EL COLOR DEL AUTO ES " + color);

    }



}
