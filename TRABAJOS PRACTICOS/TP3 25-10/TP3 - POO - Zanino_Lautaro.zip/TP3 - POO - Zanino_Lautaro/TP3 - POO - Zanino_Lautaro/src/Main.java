import java.time.Year;

public class Main {
    public static void main(String[] args) {

        Automovil auto = new Automovil(
                "BMW",
                Year.of(2025),
                3.0,
                TipoCombustible.GASOLINA,
                TipoAutomovil.COMPACTO,
                2,
                4,
                290,
                Color.BLANCO
        );

        auto.acelerar(300);
        System.out.println("\nVELOCIDAD ACTUAL: " + auto.getVelocidadActual());
        auto.acelerar(20);
        System.out.println("\nVELOCIDAD ACTUAL: " + auto.getVelocidadActual());
        auto.desacelerar(50);
        System.out.println("\nVELOCIDAD ACTUAL: " + auto.getVelocidadActual());
        auto.frenar();
        System.out.println("\nVELOCIDAD ACTUAL: " + auto.getVelocidadActual());
        System.out.println("\n¿TIENE MULTAS? " + auto.tieneMultas());
        System.out.println("\nTOTAL EN MULTAS: $" + auto.getTotalMultas());

        auto.mostrarValoresPantalla();

    }
}
