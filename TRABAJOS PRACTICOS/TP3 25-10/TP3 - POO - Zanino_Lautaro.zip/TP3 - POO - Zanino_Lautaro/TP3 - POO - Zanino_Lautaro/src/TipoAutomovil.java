public enum TipoAutomovil {
    CARRO_DE_CIUDAD,
    SUBCOMPACTO,
    COMPACTO,
    FAMILIAR,
    EJECUTIVO,
    SUV
}
