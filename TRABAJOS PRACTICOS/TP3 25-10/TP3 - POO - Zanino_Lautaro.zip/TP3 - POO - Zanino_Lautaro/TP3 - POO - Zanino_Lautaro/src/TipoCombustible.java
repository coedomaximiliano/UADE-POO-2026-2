public enum TipoCombustible {
    GASOLINA,
    BIOETANOL,
    DIESEL,
    BIODESEL,
    GAS_NATURAL
}
